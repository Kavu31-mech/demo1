/*=======================================================================
 *  MediCore – Hospital Management System
 *  C Backend Server  ·  server.c
 *
 *  ★ NO MONGOOSE NEEDED – pure POSIX sockets + SQLite3 ★
 *
 *  Modules:
 *    Authentication · Registration · EMR · Scheduler · Vaccination
 *    Patient Communication · Billing · Insurance · Pharmacy
 *    Appointment Management
 *
 *  Build (Linux/macOS):
 *    gcc server.c sqlite3.c -o medicore_server -lpthread -lm
 *
 *  Build (Windows – MinGW):
 *    gcc server.c sqlite3.c -o medicore_server.exe -lws2_32 -lpthread
 *
 *  Run:
 *    ./medicore_server
 *    Open  http://localhost:8080  in your browser
 *
 *  Admin login:  admin@medicore.in  /  admin@123
 *=======================================================================*/

/* ── Platform detection ───────────────────────────── */
#ifdef _WIN32
  #define WIN32_LEAN_AND_MEAN
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #include <direct.h>
  #include <io.h>
  #pragma comment(lib,"ws2_32.lib")
  typedef int socklen_t;
  #define CLOSESOCK(s)  closesocket(s)
  #define MKDIR(p)      _mkdir(p)
  #define strncasecmp   _strnicmp
  #define strcasecmp    _stricmp
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <sys/stat.h>
  #include <dirent.h>
  #define CLOSESOCK(s)  close(s)
  #define MKDIR(p)      mkdir((p), 0755)
  #define SOCKET        int
  #define INVALID_SOCKET (-1)
#endif

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>

#include "sqlite3.h"

/* ── Configuration ────────────────────────────────── */
#define PORT         8080
#define BACKLOG      64
#define RECV_BUF     (8 * 1024 * 1024)
#define SEND_BUF     (4 * 1024 * 1024)
#define STATIC_DIR   "."
#define DB_PATH      "./medicore.db"
#define ADMIN_EMAIL  "admin@medicore.in"
#define ADMIN_PASS   "admin@123"

/* ── Session pool ─────────────────────────────────── */
#define MAX_SESSIONS 512
#define TOKEN_LEN    40
#define SESSION_TTL  28800

typedef struct {
    char token[TOKEN_LEN+1];
    char email[128];
    int  is_admin;
    time_t expires;
    int  active;
} Session;

static Session  g_sessions[MAX_SESSIONS];
static sqlite3 *g_db = NULL;
static pthread_mutex_t g_db_mutex   = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_sess_mutex = PTHREAD_MUTEX_INITIALIZER;

/* ════════════════════════════════════════════════════
 *  Utility helpers
 * ════════════════════════════════════════════════════*/
static void gen_token(char *out){
    static const char c[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for(int i=0;i<TOKEN_LEN;i++) out[i]=c[rand()%(int)(sizeof(c)-1)];
    out[TOKEN_LEN]='\0';
}

static const char *ltrim(const char *s){ while(*s==' '||*s=='\t') s++; return s; }

static void url_decode(const char *src, char *dst, size_t dlen){
    size_t j=0;
    for(size_t i=0;src[i]&&j<dlen-1;i++){
        if(src[i]=='%'&&isxdigit((unsigned char)src[i+1])&&isxdigit((unsigned char)src[i+2])){
            char h[3]={src[i+1],src[i+2],0};
            dst[j++]=(char)strtol(h,NULL,16); i+=2;
        } else if(src[i]=='+') dst[j++]=' ';
        else dst[j++]=src[i];
    }
    dst[j]='\0';
}

static int json_get(const char *js, size_t jlen, const char *key, char *out, size_t olen){
    if(!js||!jlen){if(out)out[0]='\0';return 0;}
    char *tmp=(char*)malloc(jlen+1); if(!tmp){out[0]='\0';return 0;}
    memcpy(tmp,js,jlen); tmp[jlen]='\0';
    char search[256]; snprintf(search,sizeof(search),"\"%s\"",key);
    char *p=strstr(tmp,search);
    if(!p){free(tmp);out[0]='\0';return 0;}
    p+=strlen(search);
    while(*p==' '||*p==':'||*p=='\t') p++;
    int r=0;
    if(*p=='"'){
        p++; size_t i=0;
        while(*p&&*p!='"'&&i<olen-1){
            if(*p=='\\'&&*(p+1)){p++;
                switch(*p){case '"':out[i++]='"';break;case '\\':out[i++]='\\';break;
                    case 'n':out[i++]='\n';break;case 'r':out[i++]='\r';break;
                    case 't':out[i++]='\t';break;default:out[i++]=*p;break;}}
            else out[i++]=*p; p++;
        }
        out[i]='\0'; r=1;
    } else {
        size_t i=0;
        while(*p&&*p!=','&&*p!='}'&&*p!=']'&&i<olen-1){
            if(*p!=' '&&*p!='\t'&&*p!='\n'&&*p!='\r') out[i++]=*p; p++;}
        out[i]='\0'; r=(i>0);
    }
    free(tmp); return r;
}

static void json_esc(const char *s, char *d, size_t dl){
    size_t j=0;
    for(size_t i=0;s[i]&&j+4<dl;i++){
        unsigned char c=(unsigned char)s[i];
        if(c=='"'){d[j++]='\\';d[j++]='"';}
        else if(c=='\\'){d[j++]='\\';d[j++]='\\';}
        else if(c=='\n'){d[j++]='\\';d[j++]='n';}
        else if(c=='\r'){d[j++]='\\';d[j++]='r';}
        else if(c=='\t'){d[j++]='\\';d[j++]='t';}
        else d[j++]=c;
    }
    d[j]='\0';
}

static const char *mime_for(const char *fn){
    const char *e=strrchr(fn,'.');
    if(!e) return "application/octet-stream";
    if(!strcasecmp(e,".html")||!strcasecmp(e,".htm")) return "text/html";
    if(!strcasecmp(e,".css"))  return "text/css";
    if(!strcasecmp(e,".js"))   return "text/javascript";
    if(!strcasecmp(e,".json")) return "application/json";
    if(!strcasecmp(e,".png"))  return "image/png";
    if(!strcasecmp(e,".jpg")||!strcasecmp(e,".jpeg")) return "image/jpeg";
    if(!strcasecmp(e,".gif"))  return "image/gif";
    if(!strcasecmp(e,".ico"))  return "image/x-icon";
    if(!strcasecmp(e,".pdf"))  return "application/pdf";
    return "application/octet-stream";
}

static void qparam(const char *q, const char *key, char *out, size_t olen){
    out[0]='\0';
    char tmp[1024]; strncpy(tmp,q,1023); tmp[1023]='\0';
    char *kv=strtok(tmp,"&");
    while(kv){
        char *eq=strchr(kv,'=');
        if(eq){ *eq='\0';
            if(!strcmp(kv,key)){ url_decode(eq+1,out,olen); return; }
        }
        kv=strtok(NULL,"&");
    }
}

#define CORS_HEADERS \
    "Access-Control-Allow-Origin: *\r\n" \
    "Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS\r\n" \
    "Access-Control-Allow-Headers: Content-Type,Authorization\r\n"

/* ════════════════════════════════════════════════════
 *  HTTP Structures
 * ════════════════════════════════════════════════════*/
typedef struct {
    char  method[16];
    char  path[512];
    char  query[512];
    char  content_type[256];
    char  authorization[256];
    long  content_length;
    char *body;
    long  body_len;
    char *raw_buf;
    long  raw_len;
} HttpReq;

typedef struct { SOCKET fd; } Conn;

static void send_all(SOCKET fd, const char *d, size_t len){
    size_t sent=0;
    while(sent<len){
        int n=(int)send(fd,d+sent,(int)(len-sent),0);
        if(n<=0) break; sent+=n;
    }
}

static void json_reply(Conn *c, int code, const char *body){
    char hdr[512];
    const char *status = code==200?"OK":code==201?"Created":code==400?"Bad Request":
                         code==401?"Unauthorized":code==403?"Forbidden":
                         code==404?"Not Found":code==409?"Conflict":"Error";
    int hl=snprintf(hdr,sizeof(hdr),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %zu\r\n"
        CORS_HEADERS
        "Connection: close\r\n\r\n",
        code, status, strlen(body));
    send_all(c->fd, hdr, hl);
    send_all(c->fd, body, strlen(body));
}

static void serve_static(Conn *c, const char *uri){
    char path[512];
    if(strcmp(uri,"/")==0||strcmp(uri,"")==0)
        snprintf(path,sizeof(path),"%s/index.html",STATIC_DIR);
    else{
        char clean[512]; size_t j=0;
        for(size_t i=0;uri[i]&&j<sizeof(clean)-1;i++){
            if(uri[i]=='.'&&uri[i+1]=='.') continue;
            clean[j++]=uri[i];
        }
        clean[j]='\0';
        snprintf(path,sizeof(path),"%s%s",STATIC_DIR,clean);
    }
    FILE *fp=fopen(path,"rb");
    if(!fp){
        const char *body="<h1>404 Not Found</h1>";
        char hdr[256];
        int hl=snprintf(hdr,sizeof(hdr),
            "HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
            strlen(body));
        send_all(c->fd,hdr,hl); send_all(c->fd,body,strlen(body)); return;
    }
    fseek(fp,0,SEEK_END); long fsz=ftell(fp); fseek(fp,0,SEEK_SET);
    const char *mime=mime_for(path);
    char hdr[256];
    int hl=snprintf(hdr,sizeof(hdr),
        "HTTP/1.1 200 OK\r\nContent-Type: %s\r\nContent-Length: %ld\r\n"
        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n", mime, fsz);
    send_all(c->fd,hdr,hl);
    char buf[65536]; size_t nr;
    while((nr=fread(buf,1,sizeof(buf),fp))>0) send_all(c->fd,buf,nr);
    fclose(fp);
}

/* ── Parse HTTP ───────────────────────────────────── */
static int parse_request(char *buf, long len, HttpReq *r){
    memset(r,0,sizeof(*r));
    r->raw_buf=buf; r->raw_len=len;
    char *line_end=strstr(buf,"\r\n");
    if(!line_end) return 0;
    *line_end='\0';
    char *sp1=strchr(buf,' '); if(!sp1) return 0;
    *sp1++='\0';
    char *sp2=strchr(sp1,' '); if(!sp2) return 0;
    *sp2='\0';
    strncpy(r->method,buf,15);
    char *q=strchr(sp1,'?');
    if(q){ *q='\0'; strncpy(r->query,q+1,511); }
    strncpy(r->path,sp1,511);
    *line_end='\r';
    char *h=line_end+2;
    while(h<buf+len){
        char *end=strstr(h,"\r\n"); if(!end) break;
        *end='\0';
        if(strlen(h)==0){ h=end+2; break; }
        const char *v=ltrim(strchr(h,':')?strchr(h,':')+1:"");
        if(!strncasecmp(h,"Content-Length",14)) r->content_length=atol(v);
        else if(!strncasecmp(h,"Content-Type",12)) strncpy(r->content_type,ltrim(v),255);
        else if(!strncasecmp(h,"Authorization",13)) strncpy(r->authorization,ltrim(v),255);
        *end='\r'; h=end+2;
    }
    r->body=h; r->body_len=(long)(buf+len-h);
    return 1;
}

/* ── Session Management ───────────────────────────── */
static Session *sess_create(const char *email, int is_admin){
    pthread_mutex_lock(&g_sess_mutex);
    time_t now=time(NULL);
    Session *s=NULL;
    for(int i=0;i<MAX_SESSIONS;i++){
        if(!g_sessions[i].active||g_sessions[i].expires<now){
            s=&g_sessions[i]; break;}
    }
    if(s){
        s->active=1; s->is_admin=is_admin;
        s->expires=now+SESSION_TTL;
        strncpy(s->email,email,127);
        gen_token(s->token);
    }
    pthread_mutex_unlock(&g_sess_mutex);
    return s;
}

static Session *sess_find(const char *token){
    if(!token||!*token) return NULL;
    pthread_mutex_lock(&g_sess_mutex);
    time_t now=time(NULL);
    Session *s=NULL;
    for(int i=0;i<MAX_SESSIONS;i++){
        if(g_sessions[i].active&&g_sessions[i].expires>now&&
           strcmp(g_sessions[i].token,token)==0){s=&g_sessions[i];break;}
    }
    pthread_mutex_unlock(&g_sess_mutex);
    return s;
}

static const char *get_token(HttpReq *r){
    const char *a=r->authorization;
    if(!strncasecmp(a,"Bearer ",7)) return a+7;
    return "";
}

/* ════════════════════════════════════════════════════
 *  Database Init
 * ════════════════════════════════════════════════════*/
static void db_init(void){
    if(sqlite3_open(DB_PATH,&g_db)!=SQLITE_OK){
        fprintf(stderr,"Cannot open DB: %s\n",sqlite3_errmsg(g_db)); exit(1);}

    const char *sql =
        "PRAGMA journal_mode=WAL;"

        /* ── users (staff/admin) ── */
        "CREATE TABLE IF NOT EXISTS users("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  name TEXT NOT NULL,"
        "  email TEXT UNIQUE NOT NULL,"
        "  password TEXT NOT NULL,"
        "  phone TEXT,"
        "  role TEXT DEFAULT 'staff',"   /* admin/doctor/nurse/staff/receptionist */
        "  department TEXT,"
        "  is_admin INTEGER DEFAULT 0,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── patients ── */
        "CREATE TABLE IF NOT EXISTS patients("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  mrn TEXT UNIQUE NOT NULL,"    /* Medical Record Number */
        "  first_name TEXT NOT NULL,"
        "  last_name TEXT NOT NULL,"
        "  dob TEXT NOT NULL,"
        "  gender TEXT NOT NULL,"
        "  blood_group TEXT,"
        "  phone TEXT NOT NULL,"
        "  email TEXT,"
        "  address TEXT,"
        "  city TEXT,"
        "  emergency_contact_name TEXT,"
        "  emergency_contact_phone TEXT,"
        "  emergency_contact_relation TEXT,"
        "  allergies TEXT,"
        "  insurance_provider TEXT,"
        "  insurance_number TEXT,"
        "  status TEXT DEFAULT 'active',"
        "  registered_at TEXT DEFAULT (datetime('now')));"

        /* ── doctors ── */
        "CREATE TABLE IF NOT EXISTS doctors("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  user_id INTEGER REFERENCES users(id),"
        "  name TEXT NOT NULL,"
        "  specialization TEXT NOT NULL,"
        "  department TEXT NOT NULL,"
        "  qualification TEXT,"
        "  experience_years INTEGER DEFAULT 0,"
        "  phone TEXT,"
        "  email TEXT,"
        "  consultation_fee REAL DEFAULT 500,"
        "  is_active INTEGER DEFAULT 1,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── appointments ── */
        "CREATE TABLE IF NOT EXISTS appointments("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  appt_ref TEXT UNIQUE NOT NULL,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  doctor_id INTEGER NOT NULL REFERENCES doctors(id),"
        "  appt_date TEXT NOT NULL,"
        "  appt_time TEXT NOT NULL,"
        "  appt_type TEXT DEFAULT 'consultation',"  /* consultation/follow-up/emergency/procedure */
        "  reason TEXT,"
        "  status TEXT DEFAULT 'scheduled',"  /* scheduled/confirmed/completed/cancelled/no-show */
        "  notes TEXT,"
        "  created_by TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── EMR (Electronic Medical Records) ── */
        "CREATE TABLE IF NOT EXISTS emr("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  appointment_id INTEGER REFERENCES appointments(id),"
        "  doctor_id INTEGER NOT NULL REFERENCES doctors(id),"
        "  visit_date TEXT NOT NULL,"
        "  chief_complaint TEXT,"
        "  history_present TEXT,"
        "  past_medical_history TEXT,"
        "  physical_examination TEXT,"
        "  vitals_bp TEXT,"
        "  vitals_pulse TEXT,"
        "  vitals_temp TEXT,"
        "  vitals_weight TEXT,"
        "  vitals_height TEXT,"
        "  vitals_spo2 TEXT,"
        "  diagnosis TEXT,"
        "  icd_code TEXT,"
        "  treatment_plan TEXT,"
        "  follow_up_date TEXT,"
        "  lab_orders TEXT,"
        "  imaging_orders TEXT,"
        "  notes TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── doctor schedules / slots ── */
        "CREATE TABLE IF NOT EXISTS doctor_schedules("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  doctor_id INTEGER NOT NULL REFERENCES doctors(id),"
        "  day_of_week TEXT NOT NULL,"   /* Monday–Sunday */
        "  start_time TEXT NOT NULL,"
        "  end_time TEXT NOT NULL,"
        "  slot_duration INTEGER DEFAULT 15,"  /* minutes */
        "  max_patients INTEGER DEFAULT 20,"
        "  is_active INTEGER DEFAULT 1,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── vaccinations ── */
        "CREATE TABLE IF NOT EXISTS vaccinations("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  vaccine_name TEXT NOT NULL,"
        "  dose_number INTEGER DEFAULT 1,"
        "  batch_number TEXT,"
        "  administered_date TEXT NOT NULL,"
        "  administered_by TEXT,"
        "  next_due_date TEXT,"
        "  site TEXT,"                  /* left arm, right arm, etc. */
        "  route TEXT,"                 /* IM, SC, oral, etc. */
        "  manufacturer TEXT,"
        "  remarks TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── patient communication / messages ── */
        "CREATE TABLE IF NOT EXISTS communications("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  patient_id INTEGER REFERENCES patients(id),"
        "  comm_type TEXT NOT NULL,"    /* appointment_reminder/lab_result/general/follow_up */
        "  channel TEXT NOT NULL,"      /* sms/email/internal */
        "  subject TEXT,"
        "  message TEXT NOT NULL,"
        "  sent_by TEXT,"
        "  status TEXT DEFAULT 'sent'," /* sent/delivered/failed/pending */
        "  sent_at TEXT DEFAULT (datetime('now')));"

        /* ── billing ── */
        "CREATE TABLE IF NOT EXISTS bills("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  bill_number TEXT UNIQUE NOT NULL,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  appointment_id INTEGER REFERENCES appointments(id),"
        "  bill_date TEXT NOT NULL,"
        "  consultation_fee REAL DEFAULT 0,"
        "  lab_charges REAL DEFAULT 0,"
        "  pharmacy_charges REAL DEFAULT 0,"
        "  room_charges REAL DEFAULT 0,"
        "  other_charges REAL DEFAULT 0,"
        "  discount REAL DEFAULT 0,"
        "  tax REAL DEFAULT 0,"
        "  total_amount REAL NOT NULL,"
        "  paid_amount REAL DEFAULT 0,"
        "  balance REAL DEFAULT 0,"
        "  payment_mode TEXT,"          /* cash/card/upi/insurance */
        "  payment_status TEXT DEFAULT 'pending',"  /* pending/partial/paid */
        "  notes TEXT,"
        "  created_by TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── insurance ── */
        "CREATE TABLE IF NOT EXISTS insurance("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  provider TEXT NOT NULL,"
        "  policy_number TEXT NOT NULL,"
        "  group_number TEXT,"
        "  policy_holder_name TEXT NOT NULL,"
        "  policy_holder_dob TEXT,"
        "  relationship TEXT DEFAULT 'self',"
        "  coverage_type TEXT,"          /* individual/family/corporate */
        "  coverage_limit REAL DEFAULT 0,"
        "  deductible REAL DEFAULT 0,"
        "  copay_percent REAL DEFAULT 0,"
        "  valid_from TEXT,"
        "  valid_to TEXT,"
        "  pre_auth_required INTEGER DEFAULT 0,"
        "  status TEXT DEFAULT 'active',"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── insurance claims ── */
        "CREATE TABLE IF NOT EXISTS insurance_claims("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  claim_number TEXT UNIQUE NOT NULL,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  insurance_id INTEGER NOT NULL REFERENCES insurance(id),"
        "  bill_id INTEGER REFERENCES bills(id),"
        "  claim_date TEXT NOT NULL,"
        "  claimed_amount REAL NOT NULL,"
        "  approved_amount REAL DEFAULT 0,"
        "  diagnosis TEXT,"
        "  status TEXT DEFAULT 'submitted',"  /* submitted/under_review/approved/rejected/paid */
        "  remarks TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── pharmacy drugs inventory ── */
        "CREATE TABLE IF NOT EXISTS drugs("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  drug_code TEXT UNIQUE NOT NULL,"
        "  name TEXT NOT NULL,"
        "  generic_name TEXT,"
        "  category TEXT,"              /* antibiotic/analgesic/antihypertensive/etc */
        "  form TEXT,"                  /* tablet/capsule/syrup/injection/etc */
        "  strength TEXT,"
        "  unit TEXT DEFAULT 'tablet',"
        "  manufacturer TEXT,"
        "  stock_quantity INTEGER DEFAULT 0,"
        "  reorder_level INTEGER DEFAULT 50,"
        "  unit_price REAL DEFAULT 0,"
        "  expiry_date TEXT,"
        "  rack_location TEXT,"
        "  requires_prescription INTEGER DEFAULT 1,"
        "  is_active INTEGER DEFAULT 1,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── prescriptions ── */
        "CREATE TABLE IF NOT EXISTS prescriptions("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  rx_number TEXT UNIQUE NOT NULL,"
        "  patient_id INTEGER NOT NULL REFERENCES patients(id),"
        "  doctor_id INTEGER NOT NULL REFERENCES doctors(id),"
        "  emr_id INTEGER REFERENCES emr(id),"
        "  prescribed_date TEXT NOT NULL,"
        "  status TEXT DEFAULT 'pending',"  /* pending/dispensed/partially_dispensed/cancelled */
        "  notes TEXT,"
        "  created_at TEXT DEFAULT (datetime('now')));"

        /* ── prescription items ── */
        "CREATE TABLE IF NOT EXISTS prescription_items("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),"
        "  drug_id INTEGER NOT NULL REFERENCES drugs(id),"
        "  dosage TEXT NOT NULL,"
        "  frequency TEXT NOT NULL,"    /* once daily / twice daily / etc */
        "  duration TEXT NOT NULL,"     /* 5 days / 1 week / etc */
        "  quantity INTEGER NOT NULL,"
        "  instructions TEXT,"
        "  is_dispensed INTEGER DEFAULT 0);"

        /* ── pharmacy dispensing ── */
        "CREATE TABLE IF NOT EXISTS dispensing("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),"
        "  drug_id INTEGER NOT NULL REFERENCES drugs(id),"
        "  quantity_dispensed INTEGER NOT NULL,"
        "  unit_price REAL,"
        "  total_price REAL,"
        "  dispensed_by TEXT,"
        "  dispensed_at TEXT DEFAULT (datetime('now')));"

        /* ── seed admin ── */
        "INSERT OR IGNORE INTO users(name,email,password,role,is_admin)"
        "  VALUES('Administrator','" ADMIN_EMAIL "','" ADMIN_PASS "','admin',1);"

        /* ── seed doctors ── */
        "INSERT OR IGNORE INTO users(name,email,password,role,department)"
        "  VALUES('Dr. Arjun Sharma','arjun@medicore.in','doctor@123','doctor','Cardiology');"
        "INSERT OR IGNORE INTO users(name,email,password,role,department)"
        "  VALUES('Dr. Priya Nair','priya@medicore.in','doctor@123','doctor','Pediatrics');"
        "INSERT OR IGNORE INTO users(name,email,password,role,department)"
        "  VALUES('Dr. Rahul Verma','rahul@medicore.in','doctor@123','doctor','Orthopedics');"
        "INSERT OR IGNORE INTO users(name,email,password,role,department)"
        "  VALUES('Dr. Sunita Rao','sunita@medicore.in','doctor@123','doctor','Gynecology');"
        "INSERT OR IGNORE INTO users(name,email,password,role,department)"
        "  VALUES('Dr. Kiran Mehta','kiran@medicore.in','doctor@123','doctor','Neurology');"

        "INSERT OR IGNORE INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        "  VALUES('Dr. Arjun Sharma','Cardiology','Cardiology','MBBS, MD (Cardiology)',15,'9876543210','arjun@medicore.in',800);"
        "INSERT OR IGNORE INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        "  VALUES('Dr. Priya Nair','Pediatrics','Pediatrics','MBBS, MD (Pediatrics)',10,'9876543211','priya@medicore.in',600);"
        "INSERT OR IGNORE INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        "  VALUES('Dr. Rahul Verma','Orthopedics','Orthopedics','MBBS, MS (Ortho)',12,'9876543212','rahul@medicore.in',700);"
        "INSERT OR IGNORE INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        "  VALUES('Dr. Sunita Rao','Gynecology','Gynecology','MBBS, DGO, MS',8,'9876543213','sunita@medicore.in',650);"
        "INSERT OR IGNORE INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        "  VALUES('Dr. Kiran Mehta','Neurology','Neurology','MBBS, DM (Neurology)',20,'9876543214','kiran@medicore.in',900);"

        /* ── seed doctor schedules ── */
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Monday','09:00','13:00',15,16 FROM doctors WHERE name='Dr. Arjun Sharma';"
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Wednesday','09:00','13:00',15,16 FROM doctors WHERE name='Dr. Arjun Sharma';"
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Monday','14:00','18:00',15,16 FROM doctors WHERE name='Dr. Priya Nair';"
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Tuesday','09:00','13:00',15,16 FROM doctors WHERE name='Dr. Rahul Verma';"
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Thursday','09:00','17:00',15,32 FROM doctors WHERE name='Dr. Sunita Rao';"
        "INSERT OR IGNORE INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        "  SELECT id,'Friday','09:00','13:00',20,12 FROM doctors WHERE name='Dr. Kiran Mehta';"

        /* ── seed sample patients ── */
        "INSERT OR IGNORE INTO patients(mrn,first_name,last_name,dob,gender,blood_group,phone,email,address,city,emergency_contact_name,emergency_contact_phone,emergency_contact_relation)"
        "  VALUES('MRN-001','Rajesh','Kumar','1985-06-15','Male','O+','9900001111','rajesh@email.com','12 MG Road','Bengaluru','Meena Kumar','9900002222','Spouse');"
        "INSERT OR IGNORE INTO patients(mrn,first_name,last_name,dob,gender,blood_group,phone,email,address,city,emergency_contact_name,emergency_contact_phone,emergency_contact_relation)"
        "  VALUES('MRN-002','Lakshmi','Devi','1990-03-22','Female','B+','9900003333','lakshmi@email.com','45 Church Street','Bengaluru','Ravi Devi','9900004444','Husband');"
        "INSERT OR IGNORE INTO patients(mrn,first_name,last_name,dob,gender,blood_group,phone,email,address,city,emergency_contact_name,emergency_contact_phone,emergency_contact_relation)"
        "  VALUES('MRN-003','Arun','Patel','2005-11-10','Male','A+','9900005555','arun.p@email.com','78 Brigade Road','Bengaluru','Suresh Patel','9900006666','Father');"

        /* ── seed drugs ── */
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG001','Amoxicillin 500mg','Amoxicillin','Antibiotic','Capsule','500mg','capsule','Sun Pharma',500,8.50,'2026-12-31');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG002','Paracetamol 500mg','Paracetamol','Analgesic','Tablet','500mg','tablet','Cipla',1000,2.00,'2027-06-30');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG003','Metformin 500mg','Metformin HCL','Antidiabetic','Tablet','500mg','tablet','Dr. Reddys',800,4.50,'2026-09-30');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG004','Amlodipine 5mg','Amlodipine','Antihypertensive','Tablet','5mg','tablet','Lupin',600,6.00,'2027-03-31');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG005','Pantoprazole 40mg','Pantoprazole','Antacid','Tablet','40mg','tablet','Zydus',700,12.00,'2027-01-31');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG006','Azithromycin 250mg','Azithromycin','Antibiotic','Tablet','250mg','tablet','Abbott',300,22.00,'2026-08-31');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG007','Insulin Glargine','Insulin Glargine','Antidiabetic','Injection','100IU/mL','vial','Novo Nordisk',50,850.00,'2026-07-31');"
        "INSERT OR IGNORE INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,stock_quantity,unit_price,expiry_date)"
        "  VALUES('DRG008','Cough Syrup 100mL','Dextromethorphan','Cough & Cold','Syrup','15mg/5mL','bottle','Mankind',200,85.00,'2026-12-31');";

    char *err=NULL;
    if(sqlite3_exec(g_db,sql,NULL,NULL,&err)!=SQLITE_OK){
        fprintf(stderr,"DB init: %s\n",err); sqlite3_free(err);}
    printf("[DB] Initialised → %s\n",DB_PATH);
}

/* ── JSON array builder ───────────────────────────── */
static char *stmt_to_json_array(sqlite3_stmt *st){
    size_t cap=131072, len=0;
    char *buf=(char*)malloc(cap);
    if(!buf) return NULL;
    buf[len++]='[';
    int first=1;
    while(sqlite3_step(st)==SQLITE_ROW){
        if(!first) buf[len++]=',';
        first=0;
        buf[len++]='{';
        int ncols=sqlite3_column_count(st);
        for(int col=0;col<ncols;col++){
            const char *name=sqlite3_column_name(st,col);
            char ename[128]; json_esc(name,ename,sizeof(ename));
            if(col) buf[len++]=',';
            len+=snprintf(buf+len,cap-len,"\"%s\":",ename);
            int t=sqlite3_column_type(st,col);
            if(t==SQLITE_NULL){ len+=snprintf(buf+len,cap-len,"null"); }
            else if(t==SQLITE_INTEGER){ len+=snprintf(buf+len,cap-len,"%lld",sqlite3_column_int64(st,col)); }
            else if(t==SQLITE_FLOAT){ len+=snprintf(buf+len,cap-len,"%.2f",sqlite3_column_double(st,col)); }
            else {
                const char *v=(const char*)sqlite3_column_text(st,col);
                char ev[4096]; json_esc(v?v:"",ev,sizeof(ev));
                len+=snprintf(buf+len,cap-len,"\"%s\"",ev);
            }
            if(len>cap-1024){ cap*=2; char *nb=(char*)realloc(buf,cap); if(!nb){free(buf);return NULL;} buf=nb; }
        }
        buf[len++]='}';
    }
    buf[len++]=']'; buf[len]='\0';
    return buf;
}

/* ════════════════════════════════════════════════════
 *  MODULE: Authentication
 * ════════════════════════════════════════════════════*/

static void h_login(Conn *c, HttpReq *r){
    char email[128]={0}, pass[128]={0};
    json_get(r->body,r->body_len,"email",email,sizeof(email));
    json_get(r->body,r->body_len,"password",pass,sizeof(pass));
    if(!*email||!*pass){ json_reply(c,400,"{\"ok\":false,\"error\":\"Email and password required\"}"); return; }

    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,"SELECT id,name,email,is_admin,role FROM users WHERE email=? AND password=?",-1,&st,NULL);
    sqlite3_bind_text(st,1,email,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,pass,-1,SQLITE_STATIC);
    char resp[1024]={0};
    if(sqlite3_step(st)==SQLITE_ROW){
        char name[128]={0}, em[128]={0}, role[64]={0};
        const char *tmp_name=(const char*)sqlite3_column_text(st,1);
        const char *tmp_em  =(const char*)sqlite3_column_text(st,2);
        const char *tmp_role=(const char*)sqlite3_column_text(st,4);
        if(tmp_name) strncpy(name,tmp_name,127);
        if(tmp_em)   strncpy(em,tmp_em,127);
        if(tmp_role) strncpy(role,tmp_role,63);
        int is_admin=sqlite3_column_int(st,3);
        sqlite3_finalize(st);
        pthread_mutex_unlock(&g_db_mutex);
        Session *s=sess_create(em,is_admin);
        if(s){
            char ename[128],eem[128],erole[64];
            json_esc(name,ename,sizeof(ename));
            json_esc(em,eem,sizeof(eem));
            json_esc(role,erole,sizeof(erole));
            snprintf(resp,sizeof(resp),
                "{\"ok\":true,\"token\":\"%s\",\"name\":\"%s\",\"email\":\"%s\",\"is_admin\":%d,\"role\":\"%s\"}",
                s->token,ename,eem,is_admin,erole);
            json_reply(c,200,resp);
        } else json_reply(c,500,"{\"ok\":false,\"error\":\"Session pool full\"}");
        return;
    }
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    json_reply(c,401,"{\"ok\":false,\"error\":\"Invalid credentials\"}");
}

static void h_logout(Conn *c, HttpReq *r){
    const char *tok=get_token(r);
    pthread_mutex_lock(&g_sess_mutex);
    for(int i=0;i<MAX_SESSIONS;i++)
        if(g_sessions[i].active&&strcmp(g_sessions[i].token,tok)==0){ g_sessions[i].active=0; break; }
    pthread_mutex_unlock(&g_sess_mutex);
    json_reply(c,200,"{\"ok\":true}");
}

static void h_me(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Not logged in\"}"); return; }
    char resp[512];
    char eem[128]; json_esc(s->email,eem,sizeof(eem));
    snprintf(resp,sizeof(resp),"{\"ok\":true,\"email\":\"%s\",\"is_admin\":%d}",eem,s->is_admin);
    json_reply(c,200,resp);
}

/* ════════════════════════════════════════════════════
 *  MODULE: Patient Registration
 * ════════════════════════════════════════════════════*/

static void h_patients_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char search[128]={0};
    qparam(r->query,"q",search,sizeof(search));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*search){
        char like[256]; snprintf(like,sizeof(like),"%%%s%%",search);
        sqlite3_prepare_v2(g_db,
            "SELECT id,mrn,first_name,last_name,dob,gender,blood_group,phone,email,city,status,registered_at "
            "FROM patients WHERE first_name LIKE ? OR last_name LIKE ? OR mrn LIKE ? OR phone LIKE ? "
            "ORDER BY registered_at DESC LIMIT 100",-1,&st,NULL);
        sqlite3_bind_text(st,1,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,2,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,3,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,4,like,-1,SQLITE_TRANSIENT);
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT id,mrn,first_name,last_name,dob,gender,blood_group,phone,email,city,status,registered_at "
            "FROM patients ORDER BY registered_at DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_patient_get(Conn *c, HttpReq *r, int pid){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,"SELECT * FROM patients WHERE id=?",-1,&st,NULL);
    sqlite3_bind_int(st,1,pid);
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    if(strcmp(arr,"[]")==0){ free(arr); json_reply(c,404,"{\"ok\":false,\"error\":\"Patient not found\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    /* strip array brackets for single object */
    arr[strlen(arr)-1]='\0';
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr+1);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_patient_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char fname[64]={0},lname[64]={0},dob[32]={0},gender[16]={0},phone[32]={0};
    char blood[8]={0},email[128]={0},address[256]={0},city[64]={0};
    char emg_name[64]={0},emg_phone[32]={0},emg_rel[32]={0};
    char allergies[256]={0},ins_provider[64]={0},ins_num[64]={0};
    json_get(r->body,r->body_len,"first_name",fname,sizeof(fname));
    json_get(r->body,r->body_len,"last_name",lname,sizeof(lname));
    json_get(r->body,r->body_len,"dob",dob,sizeof(dob));
    json_get(r->body,r->body_len,"gender",gender,sizeof(gender));
    json_get(r->body,r->body_len,"phone",phone,sizeof(phone));
    json_get(r->body,r->body_len,"blood_group",blood,sizeof(blood));
    json_get(r->body,r->body_len,"email",email,sizeof(email));
    json_get(r->body,r->body_len,"address",address,sizeof(address));
    json_get(r->body,r->body_len,"city",city,sizeof(city));
    json_get(r->body,r->body_len,"emergency_contact_name",emg_name,sizeof(emg_name));
    json_get(r->body,r->body_len,"emergency_contact_phone",emg_phone,sizeof(emg_phone));
    json_get(r->body,r->body_len,"emergency_contact_relation",emg_rel,sizeof(emg_rel));
    json_get(r->body,r->body_len,"allergies",allergies,sizeof(allergies));
    json_get(r->body,r->body_len,"insurance_provider",ins_provider,sizeof(ins_provider));
    json_get(r->body,r->body_len,"insurance_number",ins_num,sizeof(ins_num));

    if(!*fname||!*lname||!*dob||!*gender||!*phone){
        json_reply(c,400,"{\"ok\":false,\"error\":\"First name, last name, DOB, gender, phone required\"}"); return; }

    /* Generate MRN */
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *cnt;
    sqlite3_prepare_v2(g_db,"SELECT COUNT(*)+1 FROM patients",-1,&cnt,NULL);
    sqlite3_step(cnt);
    int n=(int)sqlite3_column_int64(cnt,0); sqlite3_finalize(cnt);
    char mrn[32]; snprintf(mrn,sizeof(mrn),"MRN-%04d",n);

    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO patients(mrn,first_name,last_name,dob,gender,blood_group,phone,email,address,city,"
        "emergency_contact_name,emergency_contact_phone,emergency_contact_relation,allergies,insurance_provider,insurance_number)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,mrn,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,fname,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,lname,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,dob,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,gender,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,blood,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,phone,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,email,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,9,address,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,10,city,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,11,emg_name,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,12,emg_phone,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,13,emg_rel,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,14,allergies,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,15,ins_provider,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,16,ins_num,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Patient registered\",\"mrn\":\"%s\",\"id\":%lld}",mrn,last_id);
        json_reply(c,201,resp);
    } else json_reply(c,409,"{\"ok\":false,\"error\":\"Registration failed\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Doctors
 * ════════════════════════════════════════════════════*/

static void h_doctors_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "SELECT id,name,specialization,department,qualification,experience_years,phone,email,consultation_fee,is_active "
        "FROM doctors WHERE is_active=1 ORDER BY name",-1,&st,NULL);
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_doctor_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s||!s->is_admin){ json_reply(c,403,"{\"ok\":false,\"error\":\"Admin only\"}"); return; }
    char name[64]={0},spec[64]={0},dept[64]={0},qual[128]={0};
    char phone[32]={0},email[128]={0};
    char exp[8]={0},fee[16]={0};
    json_get(r->body,r->body_len,"name",name,sizeof(name));
    json_get(r->body,r->body_len,"specialization",spec,sizeof(spec));
    json_get(r->body,r->body_len,"department",dept,sizeof(dept));
    json_get(r->body,r->body_len,"qualification",qual,sizeof(qual));
    json_get(r->body,r->body_len,"phone",phone,sizeof(phone));
    json_get(r->body,r->body_len,"email",email,sizeof(email));
    json_get(r->body,r->body_len,"experience_years",exp,sizeof(exp));
    json_get(r->body,r->body_len,"consultation_fee",fee,sizeof(fee));
    if(!*name||!*spec||!*dept){ json_reply(c,400,"{\"ok\":false,\"error\":\"Name, specialization, department required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO doctors(name,specialization,department,qualification,experience_years,phone,email,consultation_fee)"
        " VALUES(?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,name,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,spec,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,dept,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,qual,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,5,atoi(exp));
    sqlite3_bind_text(st,6,phone,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,email,-1,SQLITE_STATIC);
    sqlite3_bind_double(st,8,atof(fee));
    int rc=sqlite3_step(st); sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE) json_reply(c,201,"{\"ok\":true,\"message\":\"Doctor added\"}");
    else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to add doctor\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Appointment Management
 * ════════════════════════════════════════════════════*/

static void h_appointments_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0}, did[16]={0}, date[32]={0}, status[32]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    qparam(r->query,"doctor_id",did,sizeof(did));
    qparam(r->query,"date",date,sizeof(date));
    qparam(r->query,"status",status,sizeof(status));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    const char *qsql =
        "SELECT a.id,a.appt_ref,a.appt_date,a.appt_time,a.appt_type,a.reason,a.status,a.notes,"
        "p.first_name||' '||p.last_name AS patient_name,p.mrn,p.phone,"
        "d.name AS doctor_name,d.specialization,d.department "
        "FROM appointments a "
        "JOIN patients p ON p.id=a.patient_id "
        "JOIN doctors d ON d.id=a.doctor_id "
        "ORDER BY a.appt_date DESC,a.appt_time DESC LIMIT 200";
    sqlite3_prepare_v2(g_db,qsql,-1,&st,NULL);
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_appointment_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},did[16]={0},date[32]={0},time_s[16]={0};
    char type[32]={0},reason[256]={0},notes[256]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"doctor_id",did,sizeof(did));
    json_get(r->body,r->body_len,"appt_date",date,sizeof(date));
    json_get(r->body,r->body_len,"appt_time",time_s,sizeof(time_s));
    json_get(r->body,r->body_len,"appt_type",type,sizeof(type));
    json_get(r->body,r->body_len,"reason",reason,sizeof(reason));
    json_get(r->body,r->body_len,"notes",notes,sizeof(notes));
    if(!*pid||!*did||!*date||!*time_s){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,doctor_id,appt_date,appt_time required\"}"); return; }

    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *cnt;
    sqlite3_prepare_v2(g_db,"SELECT COUNT(*)+1 FROM appointments",-1,&cnt,NULL);
    sqlite3_step(cnt);
    int n=(int)sqlite3_column_int64(cnt,0); sqlite3_finalize(cnt);
    char ref[32]; snprintf(ref,sizeof(ref),"APT-%06d",n);

    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO appointments(appt_ref,patient_id,doctor_id,appt_date,appt_time,appt_type,reason,notes,created_by)"
        " VALUES(?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,ref,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,2,atoi(pid));
    sqlite3_bind_int(st,3,atoi(did));
    sqlite3_bind_text(st,4,date,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,time_s,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,*type?type:"consultation",-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,reason,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,notes,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,9,s->email,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Appointment scheduled\",\"appt_ref\":\"%s\",\"id\":%lld}",ref,last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to create appointment\"}");
}

static void h_appointment_update(Conn *c, HttpReq *r, int aid){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char status[32]={0}, notes[256]={0};
    json_get(r->body,r->body_len,"status",status,sizeof(status));
    json_get(r->body,r->body_len,"notes",notes,sizeof(notes));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,"UPDATE appointments SET status=?,notes=? WHERE id=?",-1,&st,NULL);
    sqlite3_bind_text(st,1,status,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,notes,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,3,aid);
    int rc=sqlite3_step(st); sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE) json_reply(c,200,"{\"ok\":true,\"message\":\"Appointment updated\"}");
    else json_reply(c,500,"{\"ok\":false,\"error\":\"Update failed\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: EMR (Electronic Medical Records)
 * ════════════════════════════════════════════════════*/

static void h_emr_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT e.*,d.name AS doctor_name,d.specialization "
            "FROM emr e JOIN doctors d ON d.id=e.doctor_id "
            "WHERE e.patient_id=? ORDER BY e.visit_date DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT e.*,d.name AS doctor_name,d.specialization,"
            "p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM emr e JOIN doctors d ON d.id=e.doctor_id "
            "JOIN patients p ON p.id=e.patient_id "
            "ORDER BY e.visit_date DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_emr_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},did[16]={0},aid[16]={0},vdate[32]={0};
    char complaint[512]={0},history[512]={0},pmh[512]={0},exam[512]={0};
    char bp[32]={0},pulse[16]={0},temp[16]={0},weight[16]={0},height[16]={0},spo2[16]={0};
    char diag[256]={0},icd[32]={0},plan[512]={0},fu_date[32]={0};
    char lab_orders[256]={0},img_orders[256]={0},notes[256]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"doctor_id",did,sizeof(did));
    json_get(r->body,r->body_len,"appointment_id",aid,sizeof(aid));
    json_get(r->body,r->body_len,"visit_date",vdate,sizeof(vdate));
    json_get(r->body,r->body_len,"chief_complaint",complaint,sizeof(complaint));
    json_get(r->body,r->body_len,"history_present",history,sizeof(history));
    json_get(r->body,r->body_len,"past_medical_history",pmh,sizeof(pmh));
    json_get(r->body,r->body_len,"physical_examination",exam,sizeof(exam));
    json_get(r->body,r->body_len,"vitals_bp",bp,sizeof(bp));
    json_get(r->body,r->body_len,"vitals_pulse",pulse,sizeof(pulse));
    json_get(r->body,r->body_len,"vitals_temp",temp,sizeof(temp));
    json_get(r->body,r->body_len,"vitals_weight",weight,sizeof(weight));
    json_get(r->body,r->body_len,"vitals_height",height,sizeof(height));
    json_get(r->body,r->body_len,"vitals_spo2",spo2,sizeof(spo2));
    json_get(r->body,r->body_len,"diagnosis",diag,sizeof(diag));
    json_get(r->body,r->body_len,"icd_code",icd,sizeof(icd));
    json_get(r->body,r->body_len,"treatment_plan",plan,sizeof(plan));
    json_get(r->body,r->body_len,"follow_up_date",fu_date,sizeof(fu_date));
    json_get(r->body,r->body_len,"lab_orders",lab_orders,sizeof(lab_orders));
    json_get(r->body,r->body_len,"imaging_orders",img_orders,sizeof(img_orders));
    json_get(r->body,r->body_len,"notes",notes,sizeof(notes));
    if(!*pid||!*did||!*vdate){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,doctor_id,visit_date required\"}"); return; }

    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO emr(patient_id,appointment_id,doctor_id,visit_date,chief_complaint,history_present,"
        "past_medical_history,physical_examination,vitals_bp,vitals_pulse,vitals_temp,vitals_weight,"
        "vitals_height,vitals_spo2,diagnosis,icd_code,treatment_plan,follow_up_date,lab_orders,imaging_orders,notes)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,atoi(pid));
    sqlite3_bind_int(st,2,*aid?atoi(aid):0);
    sqlite3_bind_int(st,3,atoi(did));
    sqlite3_bind_text(st,4,vdate,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,complaint,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,history,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,pmh,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,exam,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,9,bp,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,10,pulse,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,11,temp,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,12,weight,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,13,height,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,14,spo2,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,15,diag,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,16,icd,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,17,plan,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,18,fu_date,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,19,lab_orders,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,20,img_orders,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,21,notes,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[128]; snprintf(resp,sizeof(resp),"{\"ok\":true,\"message\":\"EMR saved\",\"id\":%lld}",last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to save EMR\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Scheduler
 * ════════════════════════════════════════════════════*/

static void h_schedules_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char did[16]={0};
    qparam(r->query,"doctor_id",did,sizeof(did));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*did){
        sqlite3_prepare_v2(g_db,
            "SELECT ds.*,d.name AS doctor_name,d.specialization,d.department "
            "FROM doctor_schedules ds JOIN doctors d ON d.id=ds.doctor_id "
            "WHERE ds.doctor_id=? AND ds.is_active=1 ORDER BY ds.day_of_week,ds.start_time",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(did));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT ds.*,d.name AS doctor_name,d.specialization,d.department "
            "FROM doctor_schedules ds JOIN doctors d ON d.id=ds.doctor_id "
            "WHERE ds.is_active=1 ORDER BY d.name,ds.day_of_week,ds.start_time",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_schedule_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s||!s->is_admin){ json_reply(c,403,"{\"ok\":false,\"error\":\"Admin only\"}"); return; }
    char did[16]={0},dow[16]={0},start[16]={0},end[16]={0},slot[8]={0},maxp[8]={0};
    json_get(r->body,r->body_len,"doctor_id",did,sizeof(did));
    json_get(r->body,r->body_len,"day_of_week",dow,sizeof(dow));
    json_get(r->body,r->body_len,"start_time",start,sizeof(start));
    json_get(r->body,r->body_len,"end_time",end,sizeof(end));
    json_get(r->body,r->body_len,"slot_duration",slot,sizeof(slot));
    json_get(r->body,r->body_len,"max_patients",maxp,sizeof(maxp));
    if(!*did||!*dow||!*start||!*end){ json_reply(c,400,"{\"ok\":false,\"error\":\"doctor_id,day_of_week,start_time,end_time required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO doctor_schedules(doctor_id,day_of_week,start_time,end_time,slot_duration,max_patients)"
        " VALUES(?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,atoi(did));
    sqlite3_bind_text(st,2,dow,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,start,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,end,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,5,*slot?atoi(slot):15);
    sqlite3_bind_int(st,6,*maxp?atoi(maxp):20);
    int rc=sqlite3_step(st); sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE) json_reply(c,201,"{\"ok\":true,\"message\":\"Schedule added\"}");
    else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to add schedule\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Vaccination
 * ════════════════════════════════════════════════════*/

static void h_vaccinations_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT v.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM vaccinations v JOIN patients p ON p.id=v.patient_id "
            "WHERE v.patient_id=? ORDER BY v.administered_date DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT v.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM vaccinations v JOIN patients p ON p.id=v.patient_id "
            "ORDER BY v.administered_date DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_vaccination_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},vacc[64]={0},dose[8]={0},batch[32]={0};
    char adm_date[32]={0},adm_by[64]={0},next_due[32]={0};
    char site[32]={0},route[32]={0},mfr[64]={0},remarks[256]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"vaccine_name",vacc,sizeof(vacc));
    json_get(r->body,r->body_len,"dose_number",dose,sizeof(dose));
    json_get(r->body,r->body_len,"batch_number",batch,sizeof(batch));
    json_get(r->body,r->body_len,"administered_date",adm_date,sizeof(adm_date));
    json_get(r->body,r->body_len,"administered_by",adm_by,sizeof(adm_by));
    json_get(r->body,r->body_len,"next_due_date",next_due,sizeof(next_due));
    json_get(r->body,r->body_len,"site",site,sizeof(site));
    json_get(r->body,r->body_len,"route",route,sizeof(route));
    json_get(r->body,r->body_len,"manufacturer",mfr,sizeof(mfr));
    json_get(r->body,r->body_len,"remarks",remarks,sizeof(remarks));
    if(!*pid||!*vacc||!*adm_date){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,vaccine_name,administered_date required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO vaccinations(patient_id,vaccine_name,dose_number,batch_number,administered_date,"
        "administered_by,next_due_date,site,route,manufacturer,remarks)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,atoi(pid));
    sqlite3_bind_text(st,2,vacc,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,3,*dose?atoi(dose):1);
    sqlite3_bind_text(st,4,batch,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,adm_date,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,adm_by,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,next_due,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,site,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,9,route,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,10,mfr,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,11,remarks,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[128]; snprintf(resp,sizeof(resp),"{\"ok\":true,\"message\":\"Vaccination recorded\",\"id\":%lld}",last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to record vaccination\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Patient Communication
 * ════════════════════════════════════════════════════*/

static void h_comm_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT c.*,p.first_name||' '||p.last_name AS patient_name "
            "FROM communications c LEFT JOIN patients p ON p.id=c.patient_id "
            "WHERE c.patient_id=? ORDER BY c.sent_at DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT c.*,p.first_name||' '||p.last_name AS patient_name "
            "FROM communications c LEFT JOIN patients p ON p.id=c.patient_id "
            "ORDER BY c.sent_at DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_comm_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},type[32]={0},channel[16]={0},subject[128]={0},msg[1024]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"comm_type",type,sizeof(type));
    json_get(r->body,r->body_len,"channel",channel,sizeof(channel));
    json_get(r->body,r->body_len,"subject",subject,sizeof(subject));
    json_get(r->body,r->body_len,"message",msg,sizeof(msg));
    if(!*msg||!*type||!*channel){ json_reply(c,400,"{\"ok\":false,\"error\":\"comm_type,channel,message required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO communications(patient_id,comm_type,channel,subject,message,sent_by)"
        " VALUES(?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,*pid?atoi(pid):0);
    sqlite3_bind_text(st,2,type,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,channel,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,subject,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,msg,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,s->email,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[128]; snprintf(resp,sizeof(resp),"{\"ok\":true,\"message\":\"Message sent\",\"id\":%lld}",last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to send message\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Billing
 * ════════════════════════════════════════════════════*/

static void h_bills_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT b.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM bills b JOIN patients p ON p.id=b.patient_id "
            "WHERE b.patient_id=? ORDER BY b.bill_date DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT b.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM bills b JOIN patients p ON p.id=b.patient_id "
            "ORDER BY b.bill_date DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_bill_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},aid[16]={0},bdate[32]={0};
    char cons[16]={0},lab[16]={0},pharma[16]={0},room[16]={0},other[16]={0};
    char disc[16]={0},tax[16]={0},pmode[32]={0},notes[256]={0},paid[16]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"appointment_id",aid,sizeof(aid));
    json_get(r->body,r->body_len,"bill_date",bdate,sizeof(bdate));
    json_get(r->body,r->body_len,"consultation_fee",cons,sizeof(cons));
    json_get(r->body,r->body_len,"lab_charges",lab,sizeof(lab));
    json_get(r->body,r->body_len,"pharmacy_charges",pharma,sizeof(pharma));
    json_get(r->body,r->body_len,"room_charges",room,sizeof(room));
    json_get(r->body,r->body_len,"other_charges",other,sizeof(other));
    json_get(r->body,r->body_len,"discount",disc,sizeof(disc));
    json_get(r->body,r->body_len,"tax",tax,sizeof(tax));
    json_get(r->body,r->body_len,"payment_mode",pmode,sizeof(pmode));
    json_get(r->body,r->body_len,"paid_amount",paid,sizeof(paid));
    json_get(r->body,r->body_len,"notes",notes,sizeof(notes));
    if(!*pid||!*bdate){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,bill_date required\"}"); return; }

    double cf=atof(cons),lf=atof(lab),pf=atof(pharma),rf=atof(room),of=atof(other);
    double df=atof(disc),tf=atof(tax),paf=atof(paid);
    double total=(cf+lf+pf+rf+of)-df+tf;
    double balance=total-paf;
    const char *pstatus = paf>=total?"paid":(paf>0?"partial":"pending");

    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *cnt;
    sqlite3_prepare_v2(g_db,"SELECT COUNT(*)+1 FROM bills",-1,&cnt,NULL);
    sqlite3_step(cnt);
    int n=(int)sqlite3_column_int64(cnt,0); sqlite3_finalize(cnt);
    char bnum[32]; snprintf(bnum,sizeof(bnum),"BILL-%06d",n);

    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO bills(bill_number,patient_id,appointment_id,bill_date,consultation_fee,lab_charges,"
        "pharmacy_charges,room_charges,other_charges,discount,tax,total_amount,paid_amount,balance,"
        "payment_mode,payment_status,notes,created_by)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,bnum,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,2,atoi(pid));
    sqlite3_bind_int(st,3,*aid?atoi(aid):0);
    sqlite3_bind_text(st,4,bdate,-1,SQLITE_STATIC);
    sqlite3_bind_double(st,5,cf); sqlite3_bind_double(st,6,lf);
    sqlite3_bind_double(st,7,pf); sqlite3_bind_double(st,8,rf);
    sqlite3_bind_double(st,9,of); sqlite3_bind_double(st,10,df);
    sqlite3_bind_double(st,11,tf); sqlite3_bind_double(st,12,total);
    sqlite3_bind_double(st,13,paf); sqlite3_bind_double(st,14,balance);
    sqlite3_bind_text(st,15,pmode,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,16,pstatus,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,17,notes,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,18,s->email,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Bill created\",\"bill_number\":\"%s\",\"total\":%.2f,\"id\":%lld}",
            bnum,total,last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to create bill\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Insurance
 * ════════════════════════════════════════════════════*/

static void h_insurance_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT i.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM insurance i JOIN patients p ON p.id=i.patient_id "
            "WHERE i.patient_id=? ORDER BY i.created_at DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT i.*,p.first_name||' '||p.last_name AS patient_name,p.mrn "
            "FROM insurance i JOIN patients p ON p.id=i.patient_id "
            "ORDER BY i.created_at DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_insurance_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},provider[64]={0},policy_num[64]={0},group_num[64]={0};
    char holder[64]={0},holder_dob[32]={0},rel[32]={0},cov_type[32]={0};
    char cov_limit[16]={0},deduct[16]={0},copay[16]={0};
    char valid_from[32]={0},valid_to[32]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"provider",provider,sizeof(provider));
    json_get(r->body,r->body_len,"policy_number",policy_num,sizeof(policy_num));
    json_get(r->body,r->body_len,"group_number",group_num,sizeof(group_num));
    json_get(r->body,r->body_len,"policy_holder_name",holder,sizeof(holder));
    json_get(r->body,r->body_len,"policy_holder_dob",holder_dob,sizeof(holder_dob));
    json_get(r->body,r->body_len,"relationship",rel,sizeof(rel));
    json_get(r->body,r->body_len,"coverage_type",cov_type,sizeof(cov_type));
    json_get(r->body,r->body_len,"coverage_limit",cov_limit,sizeof(cov_limit));
    json_get(r->body,r->body_len,"deductible",deduct,sizeof(deduct));
    json_get(r->body,r->body_len,"copay_percent",copay,sizeof(copay));
    json_get(r->body,r->body_len,"valid_from",valid_from,sizeof(valid_from));
    json_get(r->body,r->body_len,"valid_to",valid_to,sizeof(valid_to));
    if(!*pid||!*provider||!*policy_num||!*holder){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,provider,policy_number,policy_holder_name required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO insurance(patient_id,provider,policy_number,group_number,policy_holder_name,"
        "policy_holder_dob,relationship,coverage_type,coverage_limit,deductible,copay_percent,valid_from,valid_to)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,atoi(pid));
    sqlite3_bind_text(st,2,provider,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,policy_num,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,group_num,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,holder,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,holder_dob,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,*rel?rel:"self",-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,cov_type,-1,SQLITE_STATIC);
    sqlite3_bind_double(st,9,atof(cov_limit));
    sqlite3_bind_double(st,10,atof(deduct));
    sqlite3_bind_double(st,11,atof(copay));
    sqlite3_bind_text(st,12,valid_from,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,13,valid_to,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[128]; snprintf(resp,sizeof(resp),"{\"ok\":true,\"message\":\"Insurance added\",\"id\":%lld}",last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to add insurance\"}");
}

static void h_claims_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "SELECT ic.*,p.first_name||' '||p.last_name AS patient_name,p.mrn,"
        "i.provider,i.policy_number "
        "FROM insurance_claims ic "
        "JOIN patients p ON p.id=ic.patient_id "
        "JOIN insurance i ON i.id=ic.insurance_id "
        "ORDER BY ic.claim_date DESC LIMIT 100",-1,&st,NULL);
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_claim_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},ins_id[16]={0},bill_id[16]={0},cdate[32]={0};
    char amount[16]={0},diag[256]={0},remarks[256]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"insurance_id",ins_id,sizeof(ins_id));
    json_get(r->body,r->body_len,"bill_id",bill_id,sizeof(bill_id));
    json_get(r->body,r->body_len,"claim_date",cdate,sizeof(cdate));
    json_get(r->body,r->body_len,"claimed_amount",amount,sizeof(amount));
    json_get(r->body,r->body_len,"diagnosis",diag,sizeof(diag));
    json_get(r->body,r->body_len,"remarks",remarks,sizeof(remarks));
    if(!*pid||!*ins_id||!*amount||!*cdate){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,insurance_id,claim_date,claimed_amount required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *cnt;
    sqlite3_prepare_v2(g_db,"SELECT COUNT(*)+1 FROM insurance_claims",-1,&cnt,NULL);
    sqlite3_step(cnt);
    int n=(int)sqlite3_column_int64(cnt,0); sqlite3_finalize(cnt);
    char cnum[32]; snprintf(cnum,sizeof(cnum),"CLM-%06d",n);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO insurance_claims(claim_number,patient_id,insurance_id,bill_id,claim_date,claimed_amount,diagnosis,remarks)"
        " VALUES(?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,cnum,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,2,atoi(pid));
    sqlite3_bind_int(st,3,atoi(ins_id));
    sqlite3_bind_int(st,4,*bill_id?atoi(bill_id):0);
    sqlite3_bind_text(st,5,cdate,-1,SQLITE_STATIC);
    sqlite3_bind_double(st,6,atof(amount));
    sqlite3_bind_text(st,7,diag,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,remarks,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Claim submitted\",\"claim_number\":\"%s\",\"id\":%lld}",cnum,last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to submit claim\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Pharmacy
 * ════════════════════════════════════════════════════*/

static void h_drugs_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char search[64]={0};
    qparam(r->query,"q",search,sizeof(search));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*search){
        char like[128]; snprintf(like,sizeof(like),"%%%s%%",search);
        sqlite3_prepare_v2(g_db,
            "SELECT * FROM drugs WHERE is_active=1 AND "
            "(name LIKE ? OR generic_name LIKE ? OR drug_code LIKE ? OR category LIKE ?) "
            "ORDER BY name LIMIT 100",-1,&st,NULL);
        sqlite3_bind_text(st,1,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,2,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,3,like,-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(st,4,like,-1,SQLITE_TRANSIENT);
    } else {
        sqlite3_prepare_v2(g_db,"SELECT * FROM drugs WHERE is_active=1 ORDER BY name LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_drug_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s||!s->is_admin){ json_reply(c,403,"{\"ok\":false,\"error\":\"Admin only\"}"); return; }
    char code[32]={0},name[64]={0},gname[64]={0},cat[32]={0},form[32]={0};
    char strength[32]={0},unit[16]={0},mfr[64]={0};
    char stock[16]={0},reorder[16]={0},price[16]={0},expiry[32]={0},rack[32]={0};
    json_get(r->body,r->body_len,"drug_code",code,sizeof(code));
    json_get(r->body,r->body_len,"name",name,sizeof(name));
    json_get(r->body,r->body_len,"generic_name",gname,sizeof(gname));
    json_get(r->body,r->body_len,"category",cat,sizeof(cat));
    json_get(r->body,r->body_len,"form",form,sizeof(form));
    json_get(r->body,r->body_len,"strength",strength,sizeof(strength));
    json_get(r->body,r->body_len,"unit",unit,sizeof(unit));
    json_get(r->body,r->body_len,"manufacturer",mfr,sizeof(mfr));
    json_get(r->body,r->body_len,"stock_quantity",stock,sizeof(stock));
    json_get(r->body,r->body_len,"reorder_level",reorder,sizeof(reorder));
    json_get(r->body,r->body_len,"unit_price",price,sizeof(price));
    json_get(r->body,r->body_len,"expiry_date",expiry,sizeof(expiry));
    json_get(r->body,r->body_len,"rack_location",rack,sizeof(rack));
    if(!*code||!*name){ json_reply(c,400,"{\"ok\":false,\"error\":\"drug_code,name required\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO drugs(drug_code,name,generic_name,category,form,strength,unit,manufacturer,"
        "stock_quantity,reorder_level,unit_price,expiry_date,rack_location)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,code,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,name,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,3,gname,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,4,cat,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,5,form,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,strength,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,7,*unit?unit:"tablet",-1,SQLITE_STATIC);
    sqlite3_bind_text(st,8,mfr,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,9,atoi(stock));
    sqlite3_bind_int(st,10,*reorder?atoi(reorder):50);
    sqlite3_bind_double(st,11,atof(price));
    sqlite3_bind_text(st,12,expiry,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,13,rack,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st); sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE) json_reply(c,201,"{\"ok\":true,\"message\":\"Drug added\"}");
    else json_reply(c,409,"{\"ok\":false,\"error\":\"Drug code already exists\"}");
}

static void h_prescriptions_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0};
    qparam(r->query,"patient_id",pid,sizeof(pid));
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    if(*pid){
        sqlite3_prepare_v2(g_db,
            "SELECT px.*,p.first_name||' '||p.last_name AS patient_name,p.mrn,"
            "d.name AS doctor_name "
            "FROM prescriptions px "
            "JOIN patients p ON p.id=px.patient_id "
            "JOIN doctors d ON d.id=px.doctor_id "
            "WHERE px.patient_id=? ORDER BY px.prescribed_date DESC",-1,&st,NULL);
        sqlite3_bind_int(st,1,atoi(pid));
    } else {
        sqlite3_prepare_v2(g_db,
            "SELECT px.*,p.first_name||' '||p.last_name AS patient_name,p.mrn,"
            "d.name AS doctor_name "
            "FROM prescriptions px "
            "JOIN patients p ON p.id=px.patient_id "
            "JOIN doctors d ON d.id=px.doctor_id "
            "ORDER BY px.prescribed_date DESC LIMIT 100",-1,&st,NULL);
    }
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_prescription_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char pid[16]={0},did[16]={0},eid[16]={0},pdate[32]={0},notes[256]={0};
    char drug_id[16]={0},dosage[64]={0},freq[64]={0},dur[32]={0},qty[16]={0},inst[128]={0};
    json_get(r->body,r->body_len,"patient_id",pid,sizeof(pid));
    json_get(r->body,r->body_len,"doctor_id",did,sizeof(did));
    json_get(r->body,r->body_len,"emr_id",eid,sizeof(eid));
    json_get(r->body,r->body_len,"prescribed_date",pdate,sizeof(pdate));
    json_get(r->body,r->body_len,"notes",notes,sizeof(notes));
    json_get(r->body,r->body_len,"drug_id",drug_id,sizeof(drug_id));
    json_get(r->body,r->body_len,"dosage",dosage,sizeof(dosage));
    json_get(r->body,r->body_len,"frequency",freq,sizeof(freq));
    json_get(r->body,r->body_len,"duration",dur,sizeof(dur));
    json_get(r->body,r->body_len,"quantity",qty,sizeof(qty));
    json_get(r->body,r->body_len,"instructions",inst,sizeof(inst));
    if(!*pid||!*did||!*pdate){ json_reply(c,400,"{\"ok\":false,\"error\":\"patient_id,doctor_id,prescribed_date required\"}"); return; }

    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *cnt;
    sqlite3_prepare_v2(g_db,"SELECT COUNT(*)+1 FROM prescriptions",-1,&cnt,NULL);
    sqlite3_step(cnt);
    int n=(int)sqlite3_column_int64(cnt,0); sqlite3_finalize(cnt);
    char rxnum[32]; snprintf(rxnum,sizeof(rxnum),"RX-%06d",n);

    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO prescriptions(rx_number,patient_id,doctor_id,emr_id,prescribed_date,notes)"
        " VALUES(?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_text(st,1,rxnum,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,2,atoi(pid));
    sqlite3_bind_int(st,3,atoi(did));
    sqlite3_bind_int(st,4,*eid?atoi(eid):0);
    sqlite3_bind_text(st,5,pdate,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,6,notes,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long rx_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);

    /* Add prescription item if drug provided */
    if(rc==SQLITE_DONE && *drug_id){
        sqlite3_stmt *st2;
        sqlite3_prepare_v2(g_db,
            "INSERT INTO prescription_items(prescription_id,drug_id,dosage,frequency,duration,quantity,instructions)"
            " VALUES(?,?,?,?,?,?,?)",-1,&st2,NULL);
        sqlite3_bind_int64(st2,1,rx_id);
        sqlite3_bind_int(st2,2,atoi(drug_id));
        sqlite3_bind_text(st2,3,dosage,-1,SQLITE_STATIC);
        sqlite3_bind_text(st2,4,freq,-1,SQLITE_STATIC);
        sqlite3_bind_text(st2,5,dur,-1,SQLITE_STATIC);
        sqlite3_bind_int(st2,6,*qty?atoi(qty):1);
        sqlite3_bind_text(st2,7,inst,-1,SQLITE_STATIC);
        sqlite3_step(st2); sqlite3_finalize(st2);
    }
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Prescription created\",\"rx_number\":\"%s\",\"id\":%lld}",rxnum,rx_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to create prescription\"}");
}

static void h_dispense_list(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "SELECT disp.*,px.rx_number,"
        "p.first_name||' '||p.last_name AS patient_name,"
        "dr.name AS drug_name,dr.form,dr.strength "
        "FROM dispensing disp "
        "JOIN prescriptions px ON px.id=disp.prescription_id "
        "JOIN patients p ON p.id=px.patient_id "
        "JOIN drugs dr ON dr.id=disp.drug_id "
        "ORDER BY disp.dispensed_at DESC LIMIT 100",-1,&st,NULL);
    char *arr=stmt_to_json_array(st);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(!arr){ json_reply(c,500,"{\"ok\":false,\"error\":\"Memory error\"}"); return; }
    char *resp=(char*)malloc(strlen(arr)+32);
    sprintf(resp,"{\"ok\":true,\"data\":%s}",arr);
    json_reply(c,200,resp);
    free(arr); free(resp);
}

static void h_dispense_create(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    char px_id[16]={0},drug_id[16]={0},qty[16]={0};
    json_get(r->body,r->body_len,"prescription_id",px_id,sizeof(px_id));
    json_get(r->body,r->body_len,"drug_id",drug_id,sizeof(drug_id));
    json_get(r->body,r->body_len,"quantity_dispensed",qty,sizeof(qty));
    if(!*px_id||!*drug_id||!*qty){ json_reply(c,400,"{\"ok\":false,\"error\":\"prescription_id,drug_id,quantity_dispensed required\"}"); return; }
    int iqty=atoi(qty);
    pthread_mutex_lock(&g_db_mutex);
    /* Get drug price and update stock */
    sqlite3_stmt *dstmt;
    sqlite3_prepare_v2(g_db,"SELECT unit_price,stock_quantity FROM drugs WHERE id=?",-1,&dstmt,NULL);
    sqlite3_bind_int(dstmt,1,atoi(drug_id));
    double unit_price=0; int stock=0;
    if(sqlite3_step(dstmt)==SQLITE_ROW){
        unit_price=sqlite3_column_double(dstmt,0);
        stock=sqlite3_column_int(dstmt,1);
    }
    sqlite3_finalize(dstmt);
    if(stock<iqty){ pthread_mutex_unlock(&g_db_mutex); json_reply(c,400,"{\"ok\":false,\"error\":\"Insufficient stock\"}"); return; }
    /* Update stock */
    sqlite3_stmt *upd;
    sqlite3_prepare_v2(g_db,"UPDATE drugs SET stock_quantity=stock_quantity-? WHERE id=?",-1,&upd,NULL);
    sqlite3_bind_int(upd,1,iqty); sqlite3_bind_int(upd,2,atoi(drug_id));
    sqlite3_step(upd); sqlite3_finalize(upd);
    /* Insert dispense record */
    sqlite3_stmt *st;
    sqlite3_prepare_v2(g_db,
        "INSERT INTO dispensing(prescription_id,drug_id,quantity_dispensed,unit_price,total_price,dispensed_by)"
        " VALUES(?,?,?,?,?,?)",-1,&st,NULL);
    sqlite3_bind_int(st,1,atoi(px_id));
    sqlite3_bind_int(st,2,atoi(drug_id));
    sqlite3_bind_int(st,3,iqty);
    sqlite3_bind_double(st,4,unit_price);
    sqlite3_bind_double(st,5,unit_price*iqty);
    sqlite3_bind_text(st,6,s->email,-1,SQLITE_STATIC);
    int rc=sqlite3_step(st);
    long long last_id=sqlite3_last_insert_rowid(g_db);
    sqlite3_finalize(st);
    pthread_mutex_unlock(&g_db_mutex);
    if(rc==SQLITE_DONE){
        char resp[256]; snprintf(resp,sizeof(resp),
            "{\"ok\":true,\"message\":\"Dispensed\",\"total\":%.2f,\"id\":%lld}",
            unit_price*iqty,last_id);
        json_reply(c,201,resp);
    } else json_reply(c,500,"{\"ok\":false,\"error\":\"Failed to dispense\"}");
}

/* ════════════════════════════════════════════════════
 *  MODULE: Admin / Dashboard Stats
 * ════════════════════════════════════════════════════*/

static void h_admin_stats(Conn *c, HttpReq *r){
    Session *s=sess_find(get_token(r));
    if(!s){ json_reply(c,401,"{\"ok\":false,\"error\":\"Unauthorized\"}"); return; }
    pthread_mutex_lock(&g_db_mutex);
    sqlite3_stmt *st;
    long long total_patients=0,total_doctors=0,appts_today=0,total_bills=0;
    double revenue_today=0,total_revenue=0;
    long long low_stock=0,vaccinations_month=0;

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*) FROM patients",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) total_patients=sqlite3_column_int64(st,0);
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*) FROM doctors WHERE is_active=1",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) total_doctors=sqlite3_column_int64(st,0);
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*) FROM appointments WHERE appt_date=date('now')",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) appts_today=sqlite3_column_int64(st,0);
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*),COALESCE(SUM(total_amount),0) FROM bills",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW){ total_bills=sqlite3_column_int64(st,0); total_revenue=sqlite3_column_double(st,1); }
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COALESCE(SUM(total_amount),0) FROM bills WHERE bill_date=date('now')",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) revenue_today=sqlite3_column_double(st,0);
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*) FROM drugs WHERE stock_quantity<=reorder_level AND is_active=1",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) low_stock=sqlite3_column_int64(st,0);
    sqlite3_finalize(st);

    sqlite3_prepare_v2(g_db,"SELECT COUNT(*) FROM vaccinations WHERE administered_date>=date('now','start of month')",-1,&st,NULL);
    if(sqlite3_step(st)==SQLITE_ROW) vaccinations_month=sqlite3_column_int64(st,0);
    sqlite3_finalize(st);

    pthread_mutex_unlock(&g_db_mutex);

    char resp[1024];
    snprintf(resp,sizeof(resp),
        "{\"ok\":true,\"data\":{"
        "\"total_patients\":%lld,"
        "\"total_doctors\":%lld,"
        "\"appointments_today\":%lld,"
        "\"total_bills\":%lld,"
        "\"revenue_today\":%.2f,"
        "\"total_revenue\":%.2f,"
        "\"low_stock_drugs\":%lld,"
        "\"vaccinations_this_month\":%lld"
        "}}",
        total_patients,total_doctors,appts_today,
        total_bills,revenue_today,total_revenue,
        low_stock,vaccinations_month);
    json_reply(c,200,resp);
}

/* ════════════════════════════════════════════════════
 *  HTTP Router
 * ════════════════════════════════════════════════════*/
static void route(Conn *c, HttpReq *r){
    const char *m=r->method, *p=r->path;

    /* CORS preflight */
    if(!strcmp(m,"OPTIONS")){
        const char *hdr="HTTP/1.1 204 No Content\r\n"
            CORS_HEADERS "Content-Length: 0\r\nConnection: close\r\n\r\n";
        send_all(c->fd,hdr,strlen(hdr)); return;
    }

    /* ── Auth ── */
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/auth/login"))  { h_login(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/auth/logout")) { h_logout(c,r); return; }
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/auth/me"))     { h_me(c,r);     return; }

    /* ── Patients ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/patients"))        { h_patients_list(c,r);   return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/patients"))        { h_patient_create(c,r);  return; }
    if(!strcmp(m,"GET") &&!strncmp(p,"/api/patients/",14)){
        int pid=atoi(p+14); h_patient_get(c,r,pid); return; }

    /* ── Doctors ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/doctors"))  { h_doctors_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/doctors"))  { h_doctor_create(c,r); return; }

    /* ── Appointments ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/appointments"))    { h_appointments_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/appointments"))    { h_appointment_create(c,r); return; }
    if(!strcmp(m,"PUT") &&!strncmp(p,"/api/appointments/",18)){
        int aid=atoi(p+18); h_appointment_update(c,r,aid); return; }

    /* ── EMR ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/emr"))  { h_emr_list(c,r);   return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/emr"))  { h_emr_create(c,r); return; }

    /* ── Scheduler ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/schedules"))  { h_schedules_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/schedules"))  { h_schedule_create(c,r); return; }

    /* ── Vaccination ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/vaccinations"))  { h_vaccinations_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/vaccinations"))  { h_vaccination_create(c,r); return; }

    /* ── Communication ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/communications"))  { h_comm_list(c,r);   return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/communications"))  { h_comm_create(c,r); return; }

    /* ── Billing ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/bills"))  { h_bills_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/bills"))  { h_bill_create(c,r); return; }

    /* ── Insurance ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/insurance"))      { h_insurance_list(c,r);  return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/insurance"))      { h_insurance_create(c,r); return; }
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/insurance/claims")){ h_claims_list(c,r);    return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/insurance/claims")){ h_claim_create(c,r);   return; }

    /* ── Pharmacy ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/pharmacy/drugs"))         { h_drugs_list(c,r);        return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/pharmacy/drugs"))         { h_drug_create(c,r);       return; }
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/pharmacy/prescriptions")) { h_prescriptions_list(c,r); return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/pharmacy/prescriptions")) { h_prescription_create(c,r); return; }
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/pharmacy/dispense"))      { h_dispense_list(c,r);     return; }
    if(!strcmp(m,"POST")&&!strcmp(p,"/api/pharmacy/dispense"))      { h_dispense_create(c,r);   return; }

    /* ── Admin stats ── */
    if(!strcmp(m,"GET") &&!strcmp(p,"/api/admin/stats"))  { h_admin_stats(c,r); return; }

    /* ── Static files ── */
    serve_static(c, p);
}

/* ════════════════════════════════════════════════════
 *  Connection thread
 * ════════════════════════════════════════════════════*/
static void *handle_conn(void *arg){
    Conn *c=(Conn*)arg;
    char *buf=(char*)malloc(RECV_BUF);
    if(!buf){ CLOSESOCK(c->fd); free(c); return NULL; }
    long total=0;
    while(total<RECV_BUF-1){
        int n=(int)recv(c->fd,buf+total,RECV_BUF-1-total,0);
        if(n<=0) break;
        total+=n;
        /* Check if we have full request */
        buf[total]='\0';
        char *hdr_end=strstr(buf,"\r\n\r\n");
        if(hdr_end){
            long hdr_len=(long)(hdr_end-buf)+4;
            /* Check content-length */
            long cl=0;
            char *cl_hdr=strstr(buf,"Content-Length:");
            if(!cl_hdr) cl_hdr=strstr(buf,"content-length:");
            if(cl_hdr) cl=atol(cl_hdr+15);
            if(total>=hdr_len+cl) break;
        }
    }
    if(total>0){
        HttpReq req;
        if(parse_request(buf,total,&req)) route(c,&req);
    }
    CLOSESOCK(c->fd);
    free(buf); free(c);
    return NULL;
}

/* ════════════════════════════════════════════════════
 *  Main
 * ════════════════════════════════════════════════════*/
int main(void){
    srand((unsigned)time(NULL));
    memset(g_sessions,0,sizeof(g_sessions));

#ifdef _WIN32
    WSADATA wd; WSAStartup(MAKEWORD(2,2),&wd);
#endif

    db_init();

    SOCKET srv=socket(AF_INET,SOCK_STREAM,0);
    if(srv==INVALID_SOCKET){ perror("socket"); return 1; }
    int opt=1;
#ifdef _WIN32
    setsockopt(srv,SOL_SOCKET,SO_REUSEADDR,(const char*)&opt,sizeof(opt));
#else
    setsockopt(srv,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
#endif

    struct sockaddr_in addr;
    memset(&addr,0,sizeof(addr));
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=INADDR_ANY;
    addr.sin_port=htons(PORT);

    if(bind(srv,(struct sockaddr*)&addr,sizeof(addr))<0){ perror("bind"); return 1; }
    if(listen(srv,BACKLOG)<0){ perror("listen"); return 1; }

    printf("╔══════════════════════════════════════════╗\n");
    printf("║   MediCore Hospital Management System    ║\n");
    printf("╠══════════════════════════════════════════╣\n");
    printf("║  Server running on http://localhost:%d  ║\n", PORT);
    printf("║  Admin login: admin@medicore.in          ║\n");
    printf("║  Password:    admin@123                  ║\n");
    printf("╚══════════════════════════════════════════╝\n");

    while(1){
        struct sockaddr_in cli; socklen_t clen=sizeof(cli);
        SOCKET fd=accept(srv,(struct sockaddr*)&cli,&clen);
        if(fd==INVALID_SOCKET) continue;
        Conn *c=(Conn*)malloc(sizeof(Conn));
        if(!c){ CLOSESOCK(fd); continue; }
        c->fd=fd;
        pthread_t tid;
        pthread_create(&tid,NULL,handle_conn,c);
        pthread_detach(tid);
    }

#ifdef _WIN32
    WSACleanup();
#endif
    sqlite3_close(g_db);
    return 0;
}
